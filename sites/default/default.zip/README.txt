This is the Drupal multisite subdirectory/subsite for the IRS Jobs
development process. All themes, files, and custom module implementations
will be stored in this repository. All shared modules, themes, and base
Drupal application code will be stored separately in the master repository to 
mitigate risk.

If you require access to the master repository, please contact mschaal@metrostarsystems.com or jdelucchi@metrostarsystems.com
