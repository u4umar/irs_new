<?php

namespace Acme\TestLib;

class Foo {}
