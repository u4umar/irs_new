RULES AUTOTAG ACTION - README

The Rules Autotag module takes a light-weight approach for autotagging
full-text content by matching taxonomy terms.

Rules Autotag depends on the rules module.

The basic rules action rules_autotag_action takes a text and a vocabulary
as input and returns all matched terms.
