<footer id="footer" role="contentinfo" class="section section--footer">
  <div class="zone-wrapper zone-wrapper--footer">
    <div class="zone zone--footer">
      <?php print render($page['footer_first']); ?>
      <?php print render($page['footer_second']); ?>
    </div>
  </div>
</footer>
